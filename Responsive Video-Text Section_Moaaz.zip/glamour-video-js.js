/* Add custom Js code below */ 
const heroSection = `
  <section class="video-moaaz">
      <div class="video-container">
          <div class="video-content">
              <h1>
                  متجرنا متخصص في تقديم أفضل منتجات العناية بالجسم
              </h1>
              <p>  
                  المصممة لتلبية احتياجاتك اليومية بجودة عالية ونتائج فعالة
              </p>
          </div>
          <div class="video-display">
              <video width="320" height="240" loop autoplay muted>
                  <source src="https://github.com/wpAzzrk/Moaaz/raw/refs/heads/main/2.mp4" type="video/mp4">
              </video>
          </div>
      </div>
  </section>
`;

const secVid = `
  <video width="320" height="240" loop autoplay muted>
  <source src="https://github.com/wpAzzrk/Moaaz/raw/refs/heads/main/videos/z.mp4">
  </video>
`;


/* Append */
document.querySelector('body.index section:first-of-type').insertAdjacentHTML('beforebegin', heroSection);

document.querySelector('.weeklyOffers .items-center.overflow-hidden').innerHTML = secVid
